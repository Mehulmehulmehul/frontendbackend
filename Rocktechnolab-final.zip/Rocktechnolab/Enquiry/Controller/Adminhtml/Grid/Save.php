<?php
namespace Rocktechnolab\Enquiry\Controller\Adminhtml\Grid;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Rocktechnolab\Enquiry\Model\EnquiryFactory
     */
    var $enquiryFactory;
       

     /* @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Rocktechnolab\Enquiry\Model\EnquiryFactory $enquiryFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,                        
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Rocktechnolab\Enquiry\Model\EnquiryFactory $enquiryFactory
    ) {         
        $this->_storeManager = $storeManager;
        parent::__construct($context);
        $this->enquiryFactory = $enquiryFactory;
    }

    /**
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        //echo '<pre>==>';print_r($data);echo '</pre>';exit;
        if (!$data) {
            $this->_redirect('grid/grid/addrow');
            return;
        }
        try {
            $rowData = $this->enquiryFactory->create();
            $storeManager = $this->_storeManager->getStore();
                       
            $rowData->setData($data);
            if (isset($data['id'])) {
                $rowData->setId($data['id']);
            }
            $rowData->save();
            $this->messageManager->addSuccess(__('Row data has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('grid/grid/index');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Rocktechnolab_Enquiry::save');
    }
}
