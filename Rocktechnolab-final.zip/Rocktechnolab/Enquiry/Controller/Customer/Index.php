<?php
namespace Rocktechnolab\Enquiry\Controller\Customer;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

use Magento\Framework\Controller\ResultFactory;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;

    protected $session;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\Controller\Result\RedirectFactory $resultRedirectFactory,
        PageFactory $resultPageFactory
    )
    {
        $this->session = $customerSession;
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->resultRedirectFactory = $resultRedirectFactory;
    }
    public function execute()
    {
        if (!$this->session->isLoggedIn())
        {
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
        else
        {            
            $enquiry = (array) $this->getRequest()->getPost();
            if(!empty($enquiry))
            {               

                 $model = $this->_objectManager->create('Rocktechnolab\Enquiry\Model\Enquiry');
                 
                 $model->setData('firstname', $enquiry['firstname']);
                 $model->setData('lastname', $enquiry['lastname']);
                 $model->setData('email', $enquiry['email']);
                 $model->setData('comment', $enquiry['comment']);
                 $saveData = $model->save();
                 if($saveData)
                 {
                    $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));   
                 }
                 $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                 $resultRedirect->setUrl('/enquiry/customer/index');
                  return $resultRedirect;
             }
            
            $this->_view->loadLayout();
            $this->_view->renderLayout();
            // $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            // $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
            // $baseurl = $storeManager->getStore()->getBaseUrl();
           
            //  $resultRedirect = $this->resultRedirectFactory->create();
            // $resultRedirect->setPath('web/magento234/enquiry/customer/index/');
            // return $resultRedirect;
        }

            
    }

}