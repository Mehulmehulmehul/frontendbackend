<?php

namespace Rocktechnolab\Enquiry\Model;

use Magento\Framework\Model\AbstractModel;
use Rocktechnolab\Enquiry\Model\ResourceModel\Enquiry as ResourceModel;

class enquiry extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}