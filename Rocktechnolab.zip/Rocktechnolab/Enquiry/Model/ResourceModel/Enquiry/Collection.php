<?php

namespace Rocktechnolab\Enquiry\Model\ResourceModel\Enquiry;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Rocktechnolab\Enquiry\Model\Enquiry as Model;
use Rocktechnolab\Enquiry\Model\ResourceModel\Enquiry as ResourceModel;

class Collection extends AbstractCollection
{
	protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}